package servlet;

import dao.user_dao;
import model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/register") // Map to the /register URL
public class register_serv extends HttpServlet {
    private final user_dao userdao = new user_dao();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        if (username != null && password != null) {
            User newUser = new User();
            newUser.setUsername(username);
            newUser.setPassword(password);
            newUser.setRole("user"); // Default role for new users

            userdao.saveUser(newUser);

// After successful registration
            resp.sendRedirect("login.jsp");
        } else {
            resp.getWriter().println("Please fill in all fields.");
        }
    }
}
