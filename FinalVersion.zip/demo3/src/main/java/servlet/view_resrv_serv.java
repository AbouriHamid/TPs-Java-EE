package servlet;

import dao.reservation_dao;
import model.Reservation;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/user/view-reservations")
public class view_resrv_serv extends HttpServlet {

    private reservation_dao reservationdao;

    @Override
    public void init() throws ServletException {
        reservationdao = new reservation_dao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle the "action" parameter
        String action = request.getParameter("action");

        if (action == null || action.equals("list")) {
            // Check if the user is logged in
            Integer userId = (Integer) request.getSession().getAttribute("userId");

            if (userId == null) {
                // Redirect to login page if not logged in
                response.sendRedirect(request.getContextPath() + "/login.jsp");
                return;
            }

            // Fetch reservations for the logged-in user
            List<Reservation> reservations = reservationdao.getReservationsByUserId(userId);

            // Add reservations to request attributes
            request.setAttribute("reservations", reservations);

            // Forward to JSP for displaying reservations
            RequestDispatcher dispatcher = request.getRequestDispatcher("/user/reservationHome.jsp");
            dispatcher.forward(request, response);
        } else {
            // Invalid action, return an error
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
        }
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.sendRedirect("view-reservations?action=list");


    }
}
