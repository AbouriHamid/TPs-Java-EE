package servlet;

import dao.room_dao;
import model.Room;

import java.util.List;

public class get_rooms_serv {
    public static void main(String[] args) {
        // Instantiate the DAO
        room_dao roomdao = new room_dao();

        // Test getAvailableRooms
        try {
            List<Room> availableRooms = roomdao.getAvailableRooms();

            // Print the results
            if (availableRooms != null && !availableRooms.isEmpty()) {
                System.out.println("Available Rooms:");
                for (Room room : availableRooms) {
                    System.out.println("ID: " + room.getId() +
                            ", Name: " + room.getName() +
                            ", Capacity: " + room.getCapacity() +
                            ", Equipment: " + room.getEquipment() +
                            ", Availability: " + room.isAvailability());
                }
            } else {
                System.out.println("No available rooms found.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}