package servlet;

import dao.reservation_dao;
import dao.user_dao;
import dao.room_dao;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/admin/statistics")
public class stats_serv extends HttpServlet {

    private reservation_dao reservationdao;
    private user_dao userdao;
    private room_dao roomdao;

    @Override
    public void init() throws ServletException {
        reservationdao = new reservation_dao();
        userdao = new user_dao();
        roomdao = new room_dao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null || action.equals("list")) {
            try {
                // Fetch statistics
                int totalReservations = reservationdao.getTotalReservations();
                int totalUsers = userdao.getTotalUsers();
                int totalRooms = roomdao.getTotalRooms();
                double averageReservationsPerUser = reservationdao.getAverageReservationsPerUser();
                List<Object[]> topFiveUsers = reservationdao.getTopFiveUsersByReservations();
                List<Object[]> roomOccupancyRates = roomdao.getRoomOccupancyRates();

                // Add statistics data to request attributes
                request.setAttribute("totalReservations", totalReservations);
                request.setAttribute("totalUsers", totalUsers);
                request.setAttribute("totalRooms", totalRooms);
                request.setAttribute("averageReservationsPerUser", averageReservationsPerUser);
                request.setAttribute("topFiveUsers", topFiveUsers);

                // Forward to the statistics JSP
                RequestDispatcher dispatcher = request.getRequestDispatcher("/admin/statistics.jsp");
                dispatcher.forward(request, response);
            } catch (Exception e) {
                e.printStackTrace();
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error fetching statistics.");
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "/admin/stats?action=list");
    }
}

