package com.example.movierecommendation.util;

import com.example.movierecommendation.model.Movie;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@Component
public class RecommendationEngine {
    
    private static final String RATINGS_FILE = "rating.csv";
    private static final String MOVIES_FILE = "movie.csv";
    
    public List<Movie> getRecommendations(String movieTitle) {
        List<Movie> recommendations = new ArrayList<>();
        try {
            String ratingsPath = new ClassPathResource(RATINGS_FILE).getFile().getAbsolutePath();
            String moviesPath = new ClassPathResource(MOVIES_FILE).getFile().getAbsolutePath();
            
            ProcessBuilder pb = new ProcessBuilder("python",
                "src/main/python/recommendation_engine.py",
                ratingsPath,
                moviesPath,
                movieTitle);
            
            Process p = pb.start();
            
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length >= 2) {
                        Movie movie = new Movie();
                        movie.setTitle(parts[0].trim());
                        movie.setSimilarity(Double.parseDouble(parts[1].trim()));
                        recommendations.add(movie);
                    }
                }
            }
            
            int exitCode = p.waitFor();
            if (exitCode != 0) {
                System.err.println("Python script exited with code " + exitCode);
                // Read error stream
                try (BufferedReader errorReader = new BufferedReader(new InputStreamReader(p.getErrorStream()))) {
                    String line;
                    while ((line = errorReader.readLine()) != null) {
                        System.err.println("Python Error: " + line);
                    }
                }
            }
            
        } catch (Exception e) {
            System.err.println("Error in recommendation engine: " + e.getMessage());
            e.printStackTrace();
        }
        
        return recommendations;
    }
} 