package com.example.movierecommendation.controller;

import com.example.movierecommendation.model.Movie;
import com.example.movierecommendation.service.MovieService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class MovieController {
    
    private final MovieService movieService;
    
    public MovieController(MovieService movieService) {
        this.movieService = movieService;
    }
    
    @GetMapping("/")
    public String home() {
        return "home";
    }
    
    @GetMapping("/recommendations")
    public String getRecommendations(@RequestParam String movieTitle, Model model) {
        List<Movie> recommendations = movieService.getRecommendations(movieTitle);
        model.addAttribute("recommendations", recommendations);
        model.addAttribute("searchedMovie", movieTitle);
        return "recommendations";
    }
} 