package com.example.movierecommendation.service;

import com.example.movierecommendation.model.Movie;
import com.example.movierecommendation.model.TMDBResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.core.io.ClassPathResource;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.stream.Collectors;

@Service
public class MovieService {
    
    private final RestTemplate restTemplate;
    private List<String> movies = new ArrayList<>();
    
    @Value("${tmdb.api.key}")
    private String tmdbApiKey;
    
    public MovieService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
        loadMovies();
    }
    
    private void loadMovies() {
        try {
            ClassPathResource resource = new ClassPathResource("movie.csv");
            BufferedReader reader = new BufferedReader(new InputStreamReader(resource.getInputStream()));
            movies = reader.lines()
                    .skip(1) // Skip header row
                    .collect(Collectors.toList());
        } catch (Exception e) {
            System.err.println("Error loading movies: " + e.getMessage());
        }
    }

    public List<Movie> getRecommendations(String movieTitle) {
        Random random = new Random();
        List<Movie> recommendations = random.ints(0, movies.size())
                .distinct()
                .limit(10)
                .mapToObj(i -> {
                    Movie movie = new Movie();
                    movie.setTitle(movies.get(i));
                    return movie;
                })
                .collect(Collectors.toList());
        
        // Enrich with movie posters if TMDB API key is available
        if (tmdbApiKey != null && !tmdbApiKey.isEmpty()) {
            recommendations.forEach(this::enrichWithMovieDetails);
        }

        return recommendations;
    }
    
    private void enrichWithMovieDetails(Movie movie) {
        try {
            String url = String.format("https://api.themoviedb.org/3/search/movie?api_key=%s&query=%s",
                tmdbApiKey, movie.getTitle());
            TMDBResponse response = restTemplate.getForObject(url, TMDBResponse.class);
            if (response != null && !response.getResults().isEmpty()) {
                String posterPath = response.getResults().get(0).getPosterPath();
                if (posterPath != null) {
                    movie.setPosterUrl("https://image.tmdb.org/t/p/w500" + posterPath);
                }
            }
        } catch (Exception e) {
            // Log error and continue without poster
            System.err.println("Error fetching movie details: " + e.getMessage());
        }
    }
} 