package com.example.movierecommendation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;
import org.springframework.core.io.ClassPathResource;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import jakarta.annotation.PostConstruct;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class MovieRecommendationSystemApplication {
    
    private static List<String> movies = new ArrayList<>();
    
    @PostConstruct
    public void loadMovies() {
        try {
            ClassPathResource resource = new ClassPathResource("movie.csv");
            BufferedReader reader = new BufferedReader(new InputStreamReader(resource.getInputStream()));
            movies = reader.lines()
                    .skip(1) // Skip header row
                    .collect(Collectors.toList());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public List<String> getRandomMovies(String inputMovie) {
        Random random = new Random();
        return random.ints(0, movies.size())
                .distinct()
                .limit(10)
                .mapToObj(movies::get)
                .collect(Collectors.toList());
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    public static void main(String[] args) {
        SpringApplication.run(MovieRecommendationSystemApplication.class, args);
    }
} 