import pandas as pd
import numpy as np
from sklearn.neighbors import NearestNeighbors
from scipy.sparse import csr_matrix
import json

class MovieRecommender:
    def __init__(self, ratings_path, movies_path):
        self.rating = pd.read_csv(ratings_path, usecols=['userId','movieId','rating'])
        self.movies = pd.read_csv(movies_path, usecols=['movieId','title'])
        self._prepare_model()
    
    def _prepare_model(self):
        all_in_one = pd.merge(self.rating, self.movies, on='movieId')
        Calculate_Rating = all_in_one.dropna(axis=0, subset=['title'])
        
        movie_ratingCount = (Calculate_Rating
            .groupby(by=['title'])['rating']
            .count()
            .reset_index()
            .rename(columns={'rating': 'totalRatingCount'})
        )
        
        combine_all = Calculate_Rating.merge(movie_ratingCount, on='title', how='left')
        rating_popular_movie = combine_all[combine_all['totalRatingCount'] >= 1000]
        
        self.matrix_pivot = rating_popular_movie.pivot_table(
            index='title',
            columns='userId',
            values='rating'
        ).fillna(0)
        
        movie_features_df_matrix = csr_matrix(self.matrix_pivot.values)
        self.model_knn = NearestNeighbors(metric='cosine', algorithm='brute')
        self.model_knn.fit(movie_features_df_matrix)
    
    def get_recommendations(self, movie_title):
        try:
            query_index = self.matrix_pivot.index.get_loc(movie_title)
            distances, indices = self.model_knn.kneighbors(
                self.matrix_pivot.iloc[query_index, :].values.reshape(1, -1),
                n_neighbors=11
            )
            
            recommendations = []
            for i in range(1, len(distances.flatten())):
                recommendations.append({
                    'title': self.matrix_pivot.index[indices.flatten()[i]],
                    'similarity': 1 - distances.flatten()[i]
                })
            
            return recommendations
            
        except KeyError:
            return []

if __name__ == "__main__":
    recommender = MovieRecommender('ratings.csv', 'movies.csv') 