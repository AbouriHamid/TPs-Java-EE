package org.example.testspring2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestSpring2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
